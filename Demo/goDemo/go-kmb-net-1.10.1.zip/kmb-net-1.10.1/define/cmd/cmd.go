package cmd

const (
	CmdConnect       = 0xaf3c2828
	CmdMouseMove     = 0xaede7345
	CmdMouseLeft     = 0x9823AE8D
	CmdMouseMiddle   = 0x97a3AE8D
	CmdMouseRight    = 0x238d8212
	CmdMouseWheel    = 0xffeead38
	CmdMouseAutoMove = 0xaede7346
	CmdKeyboardAll   = 0x123c2c2f
	CmdReboot        = 0xaa8855aa
	CmdMonitor       = 0x27388020
	CmdDebug         = 0x27382021
	CmdUnmaskAll     = 0x23344343
	CmdSetConfig     = 0x1d3d3323
	CmdSetVidPid     = 0xffed3232
	CmdShowPic       = 0x12334883
	CmdBezierMove    = 0xa238455a
	CmdMaskMouse     = 0x23234343
)
