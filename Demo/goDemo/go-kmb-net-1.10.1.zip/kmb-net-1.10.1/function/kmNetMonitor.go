package function

import (
	"fmt"
	"github.com/tobycroft/Calc"
	"main.go/define/cmd"
	"net"
)

func (self *Km) kmNetMonitor() {
	if self.MonitorPort == 0 {
		self.MonitorPort = Calc.Rand[uint32](1024, 49151)
		if self.DebugClient {
			fmt.Println("Monitor-检测到未设定端口,使用随机端口:", self.MonitorPort)
		}
	} else {
		if self.DebugClient {
			fmt.Println("Monitor-已设定端口，使用设定值:", self.MonitorPort)
		}
	}

	self.tx.Head.Cmd = cmd.CmdMonitor                     // 指令
	self.tx.Head.Rand = self.MonitorPort | (0xaa55 << 16) // 随机混淆值
	self.send <- self.tx
	return
}

func (self *Km) kmNetMonitorServer() {
	addr := &net.UDPAddr{
		IP:   net.ParseIP("0.0.0.0"), // 表示监听所有网络接口
		Port: int(self.MonitorPort),  // 设置端口号
	}

	self.connMonitor, err = net.ListenUDP("udp", addr)
	if err != nil {
		panic(fmt.Sprintln("Monitor-接收端创建出错:", err))
	}
	if self.DebugClient {
		fmt.Println("Monitor-接收端创建完成")
	}

	go self.server_monitor()
	return
}
