package function

import (
	"fmt"
	"github.com/tobycroft/Calc"
	"main.go/datastruct"
	"main.go/define/cmd"
	"net"
	"strconv"
)

func (self *Km) KmNetInit(ip string, port int, mac string) (err error) {
	self.addr = &net.UDPAddr{
		IP:   net.ParseIP(ip),
		Port: port,
	}
	self.mac = mac
	return self.kmReconnect()
}

func (self *Km) kmReconnect() (err error) {
	self.conn, err = net.DialUDP("udp", nil, self.addr)
	if err != nil {
		panic(fmt.Sprintln("盒子连接出错:", err))
	}
	go self.receiver()
	//go self.sender()
	intValue, err := strconv.ParseInt(self.mac, 16, 32)
	if err != nil {
		panic(fmt.Sprintln("UUID-Mac不正确:", err))
	}
	self.tx = datastruct.ClientTx{}
	self.tx.Head.Mac = uint32(intValue)
	self.tx.Head.Rand = Calc.Rand[uint32](0, 99999)
	self.tx.Head.Cmd = cmd.CmdConnect
	self.send <- self.tx
	return
}
