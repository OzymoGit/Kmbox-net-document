package function

import "fmt"

func (self *Km) MonitorMouse() {
	for client_tx := range self.mouseReport {
		if client_tx.Buttons == 0 {
			if self.KeyState.MouseDebug {
				fmt.Println("松开所有按键")
			}
		}
	}
}
