package function

import (
	"fmt"
	"github.com/tobycroft/Calc"
	"main.go/define/cmd"
)

func (self *Km) KmNetKeyDown(key uint8) {
	self.tx.Head.Cmd = cmd.CmdKeyboardAll
	self.tx.Head.Rand = Calc.Rand[uint32](0, 999999)
	for i, button := range self.tx.CmdKeyboard.Button {
		_, ok := self.CurrentPressed.Load(key)
		if ok {
			break
		}
		if button == 0 {
			self.CurrentPressed.Store(key, int64(i))
			self.tx.CmdKeyboard.Button[i] = key
			break
		}
	}
	self.send <- self.tx
	return
}

func (self *Km) KmNetKeyUp(key uint8) {
	self.tx.Head.Cmd = cmd.CmdKeyboardAll
	self.tx.Head.Rand = Calc.Rand[uint32](0, 999999)
	i, ok := self.CurrentPressed.LoadAndDelete(key)
	if !ok {
		if self.DebugClient {
			fmt.Println("未找到对应按键")
		}
		return
	}
	self.tx.CmdKeyboard.Button[i.(int64)] = 0
	self.send <- self.tx
	return
}
