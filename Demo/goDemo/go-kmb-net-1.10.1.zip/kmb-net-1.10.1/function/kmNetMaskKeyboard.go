package function

import (
	"main.go/define/cmd"
)

func (self *Km) KmNetUnmaskKeyboard(keyboard_key int16) {
	self.tx.Head.Cmd = cmd.CmdUnmaskAll
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag) | uint32(keyboard_key<<8)
	self.send <- self.tx
	return
}

func (self *Km) KmNetMaskKeyboard(keyboard_key int16) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag) | uint32(keyboard_key<<8)
	self.send <- self.tx
	return
}
