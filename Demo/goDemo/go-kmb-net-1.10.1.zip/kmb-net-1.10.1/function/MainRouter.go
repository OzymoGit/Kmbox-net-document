package function

import (
	"fmt"
	"main.go/define/cmd"
	"time"
)

func (self *Km) MainRouter() {
	go self.mainRouter()
}

func (self *Km) mainRouter() {
	for client_tx := range self.recv {
		Mode := client_tx.Head.Cmd
		switch Mode {

		case cmd.CmdReboot:
			fmt.Println("盒子重启", client_tx.Head.Indexpts)

			time.Sleep(5 * time.Second)
			if self.conn != nil {
				self.conn.Close()
			}
			if self.connMonitor != nil {
				self.connMonitor.Close()
			}
			if self.debug.connDebug != nil {
				self.debug.connDebug.Close()
			}
			time.Sleep(1 * time.Second)
			_ = self.kmReconnect()
			//self.kmNetMonitor()
			break

		case cmd.CmdConnect:
			fmt.Println("连接成功！", client_tx.Head.Indexpts)
			self.kmNetMonitor()
			break

		case cmd.CmdDebug:
			fmt.Println("Debug:", client_tx.Head.Indexpts, client_tx)
			self.kmNetDebugServer()
			break

		case cmd.CmdMonitor:
			self.kmNetMonitorServer()
			if self.DebugClient {
				fmt.Println("Monitor推送准备完毕，等待数据！", client_tx.Head.Indexpts)
			}
			break

		case cmd.CmdSetVidPid:
			fmt.Println("VIDPID设定完成", client_tx.Head.Rand)
			self.KmNetReboot()
			break

		case cmd.CmdUnmaskAll:
			if self.DebugClient {
				fmt.Println("清除所有按键屏蔽", client_tx.Head.Rand)
			}
			break

		case cmd.CmdMaskMouse:
			if self.DebugClient {
				fmt.Println("按键屏蔽成功", client_tx.Head.Rand)
			}
			break

		case cmd.CmdBezierMove:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdBezierMove", client_tx.CmdMouse.X, client_tx.CmdMouse.Y)
			}
			break

		case cmd.CmdKeyboardAll:
			if self.KeyState.KeyBoardDebug {
				fmt.Println("CmdKeyboardAll", client_tx.CmdKeyboard)
			}
			break

		case cmd.CmdMouseAutoMove:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseAutoMove", client_tx.CmdMouse.X, client_tx.CmdMouse.Y)
			}
			break

		case cmd.CmdMouseWheel:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseWheel", client_tx.CmdMouse.Wheel)
			}
			break

		case cmd.CmdMouseLeft:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseLeft", client_tx.CmdMouse.Button)
			}
			break

		case cmd.CmdMouseRight:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseRight", client_tx.CmdMouse.Button)
			}
			break

		case cmd.CmdMouseMiddle:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseMiddle", client_tx.CmdMouse.Button)
			}
			break

		case cmd.CmdMouseMove:
			if self.KeyState.MouseDebug {
				fmt.Println("CmdMouseMove", client_tx.CmdMouse.X, client_tx.CmdMouse.Y)
			}
			break

		case cmd.CmdShowPic:
			if self.DebugClient {
				fmt.Println("图片设定")
			}
			break

		default:
			fmt.Println("未定义事件:", client_tx.Head.Cmd, client_tx)
			break

		}
	}
}
