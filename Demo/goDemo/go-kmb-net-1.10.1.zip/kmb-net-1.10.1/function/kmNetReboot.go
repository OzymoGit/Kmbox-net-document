package function

import (
	"main.go/define/cmd"
)

func (self *Km) KmNetReboot() {
	self.tx.Head.Cmd = cmd.CmdReboot
	self.send <- self.tx
	return
}
