package function

import (
	"main.go/define/cmd"
)

func (self *Km) KmNetSetVidPid(vid, pid uint16) (err error) {
	self.tx.Head.Cmd = cmd.CmdSetVidPid
	self.tx.Head.Rand = uint32(vid) | uint32(pid)<<16
	self.send <- self.tx
	return
}
