package function

import (
	"fmt"
	"github.com/golang/freetype/truetype"
	"golang.org/x/image/font"
	"golang.org/x/image/font/gofont/gomono"
	"golang.org/x/image/math/fixed"
	"image"
	"image/color"
	"image/draw"
	"main.go/define/cmd"
	"strings"
)

//在底部显示一张128x160的图片

func (self *Km) KmNetLcdPicture(str_len_12 string) {
	buff := self.generate_img(str_len_12)
	self.tx.Head.Cmd = cmd.CmdShowPic
	for y := 0; y < 20; y++ {
		self.tx.Head.Cmd = cmd.CmdShowPic // 指令
		self.tx.Head.Rand = uint32(80 + y*4)
		self.tx.U8Buff.Buff = [1024]byte(buff[y*1024 : (y+1)*1024])
		self.send <- self.tx
	}
	return
}

var fontData = gomono.TTF // 你的字体数据
var ff, err = truetype.Parse(fontData)
var face = truetype.NewFace(ff, &truetype.Options{
	Size: 10, // 设置字体大小
	DPI:  100,
})

func (self *Km) generate_img(str string) [20480]byte {
	canvas := image.NewRGBA(image.Rect(0, 0, 128, 80))
	white := color.RGBA{0, 0, 0, 0}
	draw.Draw(canvas, canvas.Bounds(), &image.Uniform{white}, image.Point{}, draw.Src)
	str_slices := strings.Split(str, "")
	l1 := &font.Drawer{
		Dst:  canvas,
		Src:  image.White,
		Face: face,
		Dot:  fixed.P(0, 15), // 文本的位置
	}
	l2 := &font.Drawer{
		Dst:  canvas,
		Src:  image.White,
		Face: face,
		Dot:  fixed.P(0, 35), // 文本的位置
	}
	if self.DebugClient {
		fmt.Println(str_slices)
	}
	for i, slice := range str_slices {
		if i < 7 {
			l1.DrawString(slice)
		} else if i < 14 {
			l2.DrawString(slice)
		}
	}
	return [20480]byte(canvas.Pix)
}
