package datastruct

type CmdData struct {
	Buff [1024]byte
}
