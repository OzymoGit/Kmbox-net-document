package datastruct

type MouseData struct {
	Button int32
	X      int32
	Y      int32
	Wheel  int32
	Point  [10]int32 // 贝塞尔曲线控制点
}
