package datastruct

type CmdU16 struct {
	Buff [512]uint16
}
