package datastruct

type CmdHead struct {
	Mac      uint32
	Rand     uint32
	Indexpts uint32
	Cmd      uint32
}
