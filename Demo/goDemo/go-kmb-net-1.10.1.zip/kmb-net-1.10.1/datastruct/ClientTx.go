package datastruct

// 发送数据联合体
type ClientTx struct {
	Head        CmdHead
	U8Buff      CmdData
	U16Buff     CmdU16
	CmdMouse    MouseData
	CmdKeyboard KeyboardData
}
