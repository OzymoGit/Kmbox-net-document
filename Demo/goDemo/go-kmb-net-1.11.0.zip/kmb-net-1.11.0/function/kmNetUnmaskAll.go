package function

import (
	"main.go/define/cmd"
)

func (self *Km) kmNetUnmaskAll() (err error) {
	self.tx.Head.Cmd = cmd.CmdUnmaskAll
	self.KeyState.maskKeyboardMouseFlag = 0
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}
