package function

import (
	"github.com/tobycroft/Calc"
	"main.go/define/cmd"
	"main.go/define/hid"
)

func (self *Km) KmNetMouseMove(x, y uint16) {
	self.tx.Head.Cmd = cmd.CmdMouseMove
	self.tx.Head.Rand = Calc.Rand[uint32](1000, 999999)
	self.tx.CmdMouse.X = int32(x)
	self.tx.CmdMouse.Y = int32(y)
	self.send <- self.tx
}

func (self *Km) KmNetMouseLeft(is_down bool) {
	self.tx.Head.Cmd = cmd.CmdMouseLeft
	self.tx.Head.Rand = Calc.Rand[uint32](1000, 999999)
	if is_down {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button | hid.Bit0
	} else {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button &^ hid.Bit0
	}
	self.send <- self.tx
}

func (self *Km) KmNetMouseRight(is_down bool) {
	self.tx.Head.Cmd = cmd.CmdMouseRight
	self.tx.Head.Rand = Calc.Rand[uint32](1000, 999999)
	if is_down {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button | hid.Bit1
	} else {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button &^ hid.Bit1
	}
	self.send <- self.tx
}

func (self *Km) KmNetMouseMiddle(is_down bool) {
	self.tx.Head.Cmd = cmd.CmdMouseMiddle
	self.tx.Head.Rand = Calc.Rand[uint32](1000, 999999)
	if is_down {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button | hid.Bit2
	} else {
		self.tx.CmdMouse.Button = self.tx.CmdMouse.Button &^ hid.Bit2
	}
}
func (self *Km) KmNetMouseWheel(wheel int32) {
	self.tx.Head.Cmd = cmd.CmdMouseWheel
	self.tx.Head.Rand = Calc.Rand[uint32](0, 999999)
	self.tx.CmdMouse.Wheel = wheel
	//self.tx.CmdMouse.X = 1
	//self.tx.CmdMouse.Y = 1
	self.send <- self.tx
}
