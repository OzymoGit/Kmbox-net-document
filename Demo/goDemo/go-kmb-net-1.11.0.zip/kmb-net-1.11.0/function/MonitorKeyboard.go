package function

import (
	"fmt"
	"main.go/define/hid"
	"sync"
)

func (self *Km) MonitorKeyboard() {
	for client_tx := range self.keyboardReport {
		self.KeyState.waitGroup = sync.WaitGroup{}
		self.KeyState.waitGroup.Add(12)
		keyPressed := &KeyPressed{KeyPressDebug: self.KeyState.KeyBoardDebug}
		keyStayPressed := &KeyPressed{KeyPressDebug: self.KeyState.KeyBoardDebug}
		go self.KeyState.keyboard_function(client_tx.Buttons, keyPressed)
		go self.KeyState.keyboard_function(client_tx.Buttons, keyStayPressed)
		go self.keyboard_state1(client_tx.Data[0], keyPressed, keyStayPressed)
		go self.keyboard_state2(client_tx.Data[1], keyPressed, keyStayPressed)
		go self.keyboard_state3(client_tx.Data[2], keyPressed, keyStayPressed)
		go self.keyboard_state4(client_tx.Data[3], keyPressed, keyStayPressed)
		go self.keyboard_state5(client_tx.Data[4], keyPressed, keyStayPressed)
		go self.keyboard_state6(client_tx.Data[5], keyPressed, keyStayPressed)
		go self.keyboard_state7(client_tx.Data[6], keyPressed, keyStayPressed)
		go self.keyboard_state8(client_tx.Data[7], keyPressed, keyStayPressed)
		go self.keyboard_state9(client_tx.Data[8], keyPressed, keyStayPressed)
		go self.keyboard_state10(client_tx.Data[9], keyPressed, keyStayPressed)
		self.KeyState.waitGroup.Wait()
		self.KeyChannel <- KeyAll{keyPressed, keyStayPressed}
	}
}

func (self *Km) keyboard_state1(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state1.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下1:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state1.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state1.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开1:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state1.Button, false, keypress)
		self.KeyState.state1.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持1:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state2(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state2.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下2:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state2.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state2.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开2:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state2.Button, false, keypress)
		self.KeyState.state2.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持2:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state3(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state3.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下3:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state3.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state3.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开3:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state3.Button, false, keypress)
		self.KeyState.state3.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持3:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state4(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state4.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下4:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state4.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state4.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开4:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state4.Button, false, keypress)
		self.KeyState.state4.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持4:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state5(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state5.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下5:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state5.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state5.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开5:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state5.Button, false, keypress)
		self.KeyState.state5.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持5:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state6(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state6.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下6:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state6.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state6.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开6:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state6.Button, false, keypress)
		self.KeyState.state6.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持6:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state7(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state7.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下7:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state7.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state7.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开7:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state7.Button, false, keypress)
		self.KeyState.state7.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持7:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state8(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state8.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下8:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state8.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state8.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开8:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state8.Button, false, keypress)
		self.KeyState.state8.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持8:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state9(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state9.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下9:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state9.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state9.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开9:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state9.Button, false, keypress)
		self.KeyState.state9.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持9:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *Km) keyboard_state10(key uint8, keypress *KeyPressed, keyStayPressed *KeyPressed) {
	if self.KeyState.state10.Button == hid.CmdNone && key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序按下10:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		self.KeyState.keyboard_keys(key, true, keypress)
		self.KeyState.state10.Button = key
		keypress.KeyDown, keyStayPressed.KeyDown = key, key
	} else if key == hid.CmdNone && self.KeyState.state10.Button != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("顺序松开10:")
		}
		//self.KeyState.keyboard_keys(self.KeyState.state10.Button, false, keypress)
		self.KeyState.state10.Button = key
		keypress.KeyUp, keyStayPressed.KeyUp = key, key
	} else if key != hid.CmdNone {
		if self.KeyState.KeyBoardDebug {
			fmt.Print("按键保持10:")
		}
		self.KeyState.keyboard_keys(key, true, keyStayPressed)
		keypress.KeyCurrent, keyStayPressed.KeyCurrent = key, key
	}
	self.KeyState.waitGroup.Done()
}

func (self *keyboardState) keyboard_keys(key uint8, state bool, keypress *KeyPressed) {
	keypress.KeyCurrent = key
	switch key {
	//F1-F12
	case hid.CmdF1:
		keypress.F1 = state
		if self.KeyBoardDebug {
			fmt.Println("F1")
		}
		break
	case hid.CmdF2:
		keypress.F1 = state
		if self.KeyBoardDebug {
			fmt.Println("F2")
		}
		break
	case hid.CmdF3:
		keypress.F3 = state
		if self.KeyBoardDebug {
			fmt.Println("F3")
		}
		break
	case hid.CmdF4:
		keypress.F4 = state
		if self.KeyBoardDebug {
			fmt.Println("F4")
		}
		break
	case hid.CmdF5:
		keypress.F5 = state
		if self.KeyBoardDebug {
			fmt.Println("F5")
		}
		break
	case hid.CmdF6:
		keypress.F6 = state
		if self.KeyBoardDebug {
			fmt.Println("F6")
		}
		break
	case hid.CmdF7:
		keypress.F7 = state
		if self.KeyBoardDebug {
			fmt.Println("F7")
		}
		break
	case hid.CmdF8:
		keypress.F8 = state
		if self.KeyBoardDebug {
			fmt.Println("F8")
		}
		break
	case hid.CmdF9:
		keypress.F9 = state
		if self.KeyBoardDebug {
			fmt.Println("F9")
		}
		break
	case hid.CmdF10:
		keypress.F10 = state
		if self.KeyBoardDebug {
			fmt.Println("F10")
		}
		break
	case hid.CmdF11:
		keypress.F11 = state
		if self.KeyBoardDebug {
			fmt.Println("F11")
		}
		break
	case hid.CmdF12:
		keypress.F12 = state
		if self.KeyBoardDebug {
			fmt.Println("F12")
		}
		break

	//special keys
	case hid.CmdGraveAccentAndTilde:
		keypress.Backquote = state
		if self.KeyBoardDebug {
			fmt.Println("~")
		}
		break
	case hid.CmdMinusUnderscore:
		keypress.Minus = state
		if self.KeyBoardDebug {
			fmt.Println("-")
		}
		break
	case hid.CmdEqualPlus:
		keypress.Equals = state
		if self.KeyBoardDebug {
			fmt.Println("=")
		}
		break
	case hid.CmdOBracketAndOBrace:
		keypress.BraceL = state
		if self.KeyBoardDebug {
			fmt.Println("{[")
		}
		break
	case hid.CmdCBRacketAndCBrace:
		keypress.BraceR = state
		if self.KeyBoardDebug {
			fmt.Println("}]")
		}
		break
	case hid.CmdBackslashVerticalBar:
		keypress.Backslash = state
		if self.KeyBoardDebug {
			fmt.Println("\\|")
		}
		break
	case hid.CmdSemicolonColon:
		keypress.Semicolon = state
		if self.KeyBoardDebug {
			fmt.Println(";:")
		}
		break
	case hid.CmdSingleAndDoubleQuote:
		keypress.Quote = state
		if self.KeyBoardDebug {
			fmt.Println("'\"")
		}
		break
	case hid.CmdCommaAndLess:
		keypress.Comma = state
		if self.KeyBoardDebug {
			fmt.Println("<,")
		}
		break
	case hid.CmdDotGreater:
		keypress.Dot = state
		if self.KeyBoardDebug {
			fmt.Println(".>")
		}
		break
	case hid.CmdSlashQuestion:
		keypress.QuestionSlash = state
		if self.KeyBoardDebug {
			fmt.Println("?/")
		}
		break

	//0-9
	case hid.Cmd0CParenthesis:
		keypress.Num0 = state
		if self.KeyBoardDebug {
			fmt.Println("0")
		}
		break
	case hid.Cmd1ExclamationMark:
		keypress.Num1 = state
		if self.KeyBoardDebug {
			fmt.Println("1")
		}
		break
	case hid.Cmd2At:
		keypress.Num2 = state
		if self.KeyBoardDebug {
			fmt.Println("2")
		}
		break
	case hid.Cmd3NumberSign:
		keypress.Num3 = state
		if self.KeyBoardDebug {
			fmt.Println("3")
		}
		break
	case hid.Cmd4Dollar:
		keypress.Num4 = state
		if self.KeyBoardDebug {
			fmt.Println("4")
		}
		break
	case hid.Cmd5Percent:
		keypress.Num5 = state
		if self.KeyBoardDebug {
			fmt.Println("5")
		}
		break
	case hid.Cmd6Caret:
		keypress.Num6 = state
		if self.KeyBoardDebug {
			fmt.Println("6")
		}
		break
	case hid.Cmd7Ampersand:
		keypress.Num7 = state
		if self.KeyBoardDebug {
			fmt.Println("7")
		}
		break
	case hid.Cmd8Asterisk:
		keypress.Num8 = state
		if self.KeyBoardDebug {
			fmt.Println("8")
		}
		break
	case hid.Cmd9OParenthesis:
		keypress.Num9 = state
		if self.KeyBoardDebug {
			fmt.Println("9")
		}
		break

	//A-Z
	case hid.CmdA:
		keypress.A = state
		if self.KeyBoardDebug {
			fmt.Println("A")
		}
		break
	case hid.CmdB:
		keypress.B = state
		if self.KeyBoardDebug {
			fmt.Println("B")
		}
		break
	case hid.CmdC:
		keypress.C = state
		if self.KeyBoardDebug {
			fmt.Println("C")
		}
		break
	case hid.CmdD:
		keypress.D = state
		if self.KeyBoardDebug {
			fmt.Println("D")
		}
		break
	case hid.CmdE:
		keypress.E = state
		if self.KeyBoardDebug {
			fmt.Println("E")
		}
		break
	case hid.CmdF:
		keypress.F = state
		if self.KeyBoardDebug {
			fmt.Println("F")
		}
		break
	case hid.CmdG:
		keypress.G = state
		if self.KeyBoardDebug {
			fmt.Println("G")
		}
		break
	case hid.CmdH:
		keypress.H = state
		if self.KeyBoardDebug {
			fmt.Println("H")
		}
		break
	case hid.CmdI:
		keypress.I = state
		if self.KeyBoardDebug {
			fmt.Println("I")
		}
		break
	case hid.CmdJ:
		keypress.J = state
		if self.KeyBoardDebug {
			fmt.Println("J")
		}
		break
	case hid.CmdK:
		keypress.K = state
		if self.KeyBoardDebug {
			fmt.Println("K")
		}
		break
	case hid.CmdL:
		keypress.L = state
		if self.KeyBoardDebug {
			fmt.Println("L")
		}
		break
	case hid.CmdM:
		keypress.M = state
		if self.KeyBoardDebug {
			fmt.Println("M")
		}
		break
	case hid.CmdN:
		keypress.N = state
		if self.KeyBoardDebug {
			fmt.Println("N")
		}
		break
	case hid.CmdO:
		keypress.O = state
		if self.KeyBoardDebug {
			fmt.Println("O")
		}
		break
	case hid.CmdP:
		keypress.P = state
		if self.KeyBoardDebug {
			fmt.Println("P")
		}
		break
	case hid.CmdQ:
		keypress.Q = state
		if self.KeyBoardDebug {
			fmt.Println("Q")
		}
		break
	case hid.CmdR:
		keypress.R = state
		if self.KeyBoardDebug {
			fmt.Println("R")
		}
		break
	case hid.CmdS:
		keypress.S = state
		if self.KeyBoardDebug {
			fmt.Println("S")
		}
		break
	case hid.CmdT:
		keypress.T = state
		if self.KeyBoardDebug {
			fmt.Println("T")
		}
		break
	case hid.CmdU:
		keypress.U = state
		if self.KeyBoardDebug {
			fmt.Println("U")
		}
		break
	case hid.CmdV:
		keypress.V = state
		if self.KeyBoardDebug {
			fmt.Println("V")
		}
		break
	case hid.CmdW:
		keypress.W = state
		if self.KeyBoardDebug {
			fmt.Println("W")
		}
		break
	case hid.CmdX:
		keypress.X = state
		if self.KeyBoardDebug {
			fmt.Println("X")
		}
		break
	case hid.CmdY:
		keypress.Y = state
		if self.KeyBoardDebug {
			fmt.Println("Y")
		}
		break
	case hid.CmdZ:
		keypress.Z = state
		if self.KeyBoardDebug {
			fmt.Println("Z")
		}
		break

	//function key
	case hid.CmdPrintScreen:
		keypress.PrintScreen = state
		if self.KeyBoardDebug {
			fmt.Println("PrintScreen")
		}
		break
	case hid.CmdScrollLock:
		keypress.ScrollLock = state
		if self.KeyBoardDebug {
			fmt.Println("ScrollLock")
		}
		break
	case hid.CmdPause:
		keypress.PauseBreak = state
		if self.KeyBoardDebug {
			fmt.Println("PauseBreak")
		}
		break
	case hid.CmdInsert:
		keypress.Insert = state
		if self.KeyBoardDebug {
			fmt.Println("Insert")
		}
		break
	case hid.CmdHome:
		keypress.Home = state
		if self.KeyBoardDebug {
			fmt.Println("Home")
		}
		break
	case hid.CmdPageUp:
		keypress.PageUp = state
		if self.KeyBoardDebug {
			fmt.Println("PageUp")
		}
		break
	case hid.CmdEnd1:
		keypress.End = state
		if self.KeyBoardDebug {
			fmt.Println("End")
		}
		break
	case hid.CmdPageDown:
		keypress.PageDown = state
		if self.KeyBoardDebug {
			fmt.Println("PageDown")
		}
		break
	case hid.CmdCapsLock:
		keypress.CapsLock = state
		if self.KeyBoardDebug {
			fmt.Println("CapsLock")
		}
		break
	case hid.CmdTab:
		keypress.Tab = state
		if self.KeyBoardDebug {
			fmt.Println("Tab")
		}
		break
	case hid.CmdBackspace:
		keypress.Backspace = state
		if self.KeyBoardDebug {
			fmt.Println("Backspace")
		}
		break
	case hid.CmdEnter:
		keypress.Enter = state
		if self.KeyBoardDebug {
			fmt.Println("Enter")
		}
		break
	case hid.CmdSpacebar:
		keypress.Space = state
		if self.KeyBoardDebug {
			fmt.Println("Space")
		}
		break
	case hid.CmdEscape:
		keypress.Esc = state
		if self.KeyBoardDebug {
			fmt.Println("Esc")
		}
		break
	case hid.CmdDelete:
		keypress.Delete = state
		if self.KeyBoardDebug {
			fmt.Println("Delete")
		}
		break

	//arrow keys
	case hid.CmdUpArrow:
		keypress.ArrowUp = state
		if self.KeyBoardDebug {
			fmt.Println("ArrowUp")
		}
		break
	case hid.CmdDownArrow:
		keypress.ArrowDown = state
		if self.KeyBoardDebug {
			fmt.Println("ArrowDown")
		}
		break
	case hid.CmdLeftArrow:
		keypress.ArrowLeft = state
		if self.KeyBoardDebug {
			fmt.Println("ArrowLeft")
		}
		break
	case hid.CmdRightArrow:
		keypress.ArrowRight = state
		if self.KeyBoardDebug {
			fmt.Println("ArrowRight")
		}
		break

	//keypad
	case hid.CmdKeypad0Insert:
		keypress.NumPad0 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad0")
		}
		break
	case hid.CmdKeypad1End:
		keypress.NumPad1 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad1")
		}
		break
	case hid.CmdKeypad2DownArrow:
		keypress.NumPad2 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad2")
		}
		break
	case hid.CmdKeypad3PageDown:
		keypress.NumPad3 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad3")
		}
		break
	case hid.CmdKeypad4LeftArrow:
		keypress.NumPad4 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad4")
		}
		break
	case hid.CmdKeypad5:
		keypress.NumPad5 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad5")
		}
		break
	case hid.CmdKeypad6RightArrow:
		keypress.NumPad6 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad6")
		}
		break
	case hid.CmdKeypad7Home:
		keypress.NumPad7 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad7")
		}
		break
	case hid.CmdKeypad8UpArrow:
		keypress.NumPad8 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad8")
		}
		break
	case hid.CmdKeypad9PageUp:
		keypress.NumPad9 = state
		if self.KeyBoardDebug {
			fmt.Println("NumPad9")
		}
		break
	case hid.CmdKeypadMinus:
		keypress.NumPadMinus = state
		if self.KeyBoardDebug {
			fmt.Println("NumPadMinus")
		}
		break
	case hid.CmdKeypadPlus:
		keypress.NumPadPlus = state
		if self.KeyBoardDebug {
			fmt.Println("CmdKeypadPlus")
		}
		break
	case hid.CmdKeypadAsterisk:
		keypress.NumPadMultiply = state
		if self.KeyBoardDebug {
			fmt.Println("NumPadMultiply")
		}
		break
	case hid.CmdKeypadNumLockAndClear:
		keypress.NumLock = state
		if self.KeyBoardDebug {
			fmt.Println("NumLock")
		}
		break
	case hid.CmdKeypadSlash:
		keypress.NumPadDivide = state
		if self.KeyBoardDebug {
			fmt.Println("NumPadDivide")
		}
		break
	case hid.CmdKeypadEnter:
		keypress.NumPadEnter = state
		if self.KeyBoardDebug {
			fmt.Println("NumPadEnter")
		}
		break
	case hid.CmdKeypadDecimalSeparatorDelete:
		keypress.NumPadDot = state
		if self.KeyBoardDebug {
			fmt.Println("NumPadDot")
		}
		break

	case hid.CmdApplication:
		keypress.Application = state
		if self.KeyBoardDebug {
			fmt.Println("Application")
		}

	default:
		fmt.Println(key)
		break
	}
}

func (self *keyboardState) keyboard_function_reset(keypress *KeyPressed) {
	keypress.LeftCtrl = false
	keypress.LeftShift = false
	keypress.LeftAlt = false
	keypress.RightCtrl = false
	keypress.RightShift = false
	keypress.RightAlt = false
	keypress.LeftWindows = false
	keypress.RightWindows = false
}

func (self *keyboardState) keyboard_function(key uint8, keypress *KeyPressed) {
	if key == hid.CmdNone && self.currentFunctionKey != hid.CmdNone {
		self.currentFunctionKey = hid.CmdNone
		self.keyboard_function_reset(keypress)
		if self.KeyBoardDebug {
			fmt.Println("松开所有功能键")
		}
	} else {
		self.currentFunctionKey = key
		self.keyboard_function_reset(keypress)
		switch key {
		case hid.CmdNone:
			break
		case hid.LeftCtrl:
			if self.KeyBoardDebug {
				fmt.Println("按下了左 Ctrl 键")
			} // 设置左 Ctrl 键按下的状态为 true
			keypress.LeftCtrl = true
			break
		case hid.LeftShift:
			if self.KeyBoardDebug {
				fmt.Println("按下了左 Shift 键")
			} // 设置左 Shift 键按下的状态为 true
			keypress.LeftShift = true
			break
		case hid.LeftCtrl + hid.LeftShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl 和左 Shift 键")
			} // 设置左 Ctrl 和左 Shift 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.LeftShift = true
			break
		case hid.LeftCtrl + hid.LeftAlt:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl 和左 Alt 键")
			} // 设置左 Ctrl 和左 Alt 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.LeftAlt = true
			break
		case hid.LeftCtrl + hid.LeftAlt + hid.LeftShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl、左 Alt 和左 Shift 键")
			} // 设置左 Ctrl、左 Alt 和左 Shift 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.LeftAlt = true
			keypress.LeftShift = true
			break
		case hid.RightCtrl:
			if self.KeyBoardDebug {
				fmt.Println("按下了右 Ctrl 键")
			} // 设置右 Ctrl 键按下的状态为 true
			keypress.RightCtrl = true
			break
		case hid.LeftAlt:
			if self.KeyBoardDebug {
				fmt.Println("按下了左 Alt 键")
			} // 设置左 Alt 键按下的状态为 true
			keypress.LeftAlt = true
			break
		case hid.LeftAlt + hid.LeftShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Alt 和左 Shift 键")
			} // 设置左 Alt 和左 Shift 键同时按下的状态为 true
			keypress.LeftAlt = true
			keypress.LeftShift = true
			break
		case hid.RightCtrl + hid.RightShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了右 Ctrl 和右 Shift 键")
			} // 设置右 Ctrl 和右 Shift 键同时按下的状态为 true
			keypress.RightCtrl = true
			keypress.RightShift = true
			break
		case hid.LeftCtrl + hid.RightShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl 和右 Shift 键")
			} // 设置左 Ctrl 和右 Shift 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.RightShift = true
			break
		case hid.LeftCtrl + hid.RightAlt:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl 和右 Alt 键")
			} // 设置左 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.RightAlt = true
			break
		case hid.RightAlt + hid.RightShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了右 Alt 和右 Shift 键")
			} // 设置右 Alt 和右 Shift 键同时按下的状态为 true
			keypress.RightAlt = true
			keypress.RightShift = true
			break
		case hid.LeftCtrl + hid.LeftAlt + hid.RightCtrl + hid.RightAlt:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了左 Ctrl、左 Alt、右 Ctrl 和右 Alt 键")
			} // 设置左 Ctrl、左 Alt、右 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.LeftCtrl = true
			keypress.LeftAlt = true
			keypress.RightCtrl = true
			keypress.RightAlt = true
			break
		case hid.RightAlt:
			if self.KeyBoardDebug {
				fmt.Println("按下了右 Alt 键")
			} // 设置右 Alt 键按下的状态为 true
			keypress.RightAlt = true
			break
		case hid.RightShift:
			if self.KeyBoardDebug {
				fmt.Println("按下了右 Shift 键")
			} // 设置右 Shift 键按下的状态为 true
			keypress.RightShift = true
			break
		case hid.RightCtrl + hid.RightAlt:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了右 Ctrl 和右 Alt 键")
			} // 设置右 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.RightCtrl = true
			keypress.RightAlt = true
			break
		case hid.RightCtrl + hid.RightAlt + hid.RightShift:
			if self.KeyBoardDebug {
				fmt.Println("同时按下了右 Ctrl 和右 Alt 键 和右Shift")
			} // 设置右 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.RightCtrl = true
			keypress.RightAlt = true
			keypress.RightShift = true
			break

		case hid.LeftWindows:
			if self.KeyBoardDebug {
				fmt.Println("左Windows")
			} // 设置右 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.LeftWindows = true
			break

		case hid.RightWindows:
			if self.KeyBoardDebug {
				fmt.Println("右Windows")
			} // 设置右 Ctrl 和右 Alt 键同时按下的状态为 true
			keypress.RightWindows = true
			break

		default:
			fmt.Println("按下了未知的键", key)
			break
		}
	}
	self.waitGroup.Done()
}
