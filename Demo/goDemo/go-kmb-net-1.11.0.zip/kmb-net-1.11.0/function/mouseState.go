package function

type mouseMove struct {
	Left      bool
	Right     bool
	Middle    bool
	WheelUp   bool
	WheelDown bool
	X         int16
	Y         int16
}
