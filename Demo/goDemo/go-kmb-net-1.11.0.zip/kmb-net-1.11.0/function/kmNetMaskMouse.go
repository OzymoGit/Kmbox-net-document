package function

import (
	"main.go/define/cmd"
	"main.go/define/hid"
)

func (self *Km) kmNetMaskMouseLeft(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit0
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit0
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseRight(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit1
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit1
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseMiddle(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit2
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit2
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseSlide1(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit3
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit3
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseSlide2(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit4
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit4
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseSlideX(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit5
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit5
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseSlideY(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit6
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit6
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}

func (self *Km) kmNetMaskMouseWheel(enable bool) {
	self.tx.Head.Cmd = cmd.CmdMaskMouse
	if enable {
		self.KeyState.maskKeyboardMouseFlag |= hid.Bit7
	} else {
		self.KeyState.maskKeyboardMouseFlag &= ^hid.Bit7
	}
	self.tx.Head.Rand = uint32(self.KeyState.maskKeyboardMouseFlag)
	self.send <- self.tx
	return
}
