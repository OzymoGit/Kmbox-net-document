package function

import (
	"fmt"
	"github.com/tobycroft/Calc"
	"main.go/define/cmd"
	"net"
)

func (self *Km) KmNetDebug() (err error) {
	if self.DebugPort == 0 {
		self.DebugPort = Calc.Rand[uint32](1024, 49151)
		if self.DebugClient {
			fmt.Println("Debug-检测到未设定端口,使用随机端口:", self.DebugPort)
		}
	} else {
		if self.DebugClient {
			fmt.Println("Debug-已设定端口，使用设定值:", self.DebugPort)
		}
	}
	self.tx.Head.Cmd = cmd.CmdDebug
	self.tx.Head.Rand = self.DebugPort | (1 << 16)
	self.send <- self.tx
	return
}

func (self *Km) kmNetDebugServer() {
	addr := &net.UDPAddr{
		IP:   net.ParseIP("0.0.0.0"), // 表示监听所有网络接口
		Port: int(self.DebugPort),    // 设置端口号
	}
	self.connDebug, err = net.ListenUDP("udp", addr)
	if err != nil {
		panic(fmt.Sprintln("Debug-接收端创建出错:", err))
	}
	if self.DebugClient {
		fmt.Println("Debug-接收端创建完成")
	}
	go self.server_debug()
	return
}
