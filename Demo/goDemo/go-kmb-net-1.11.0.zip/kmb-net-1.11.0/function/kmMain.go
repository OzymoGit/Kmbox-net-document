package function

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"main.go/datastruct"
	"main.go/define/cmd"
	"net"
	"runtime"
	"sync"
	"sync/atomic"
	"time"
	"unsafe"
)

type Km struct {
	DebugClient  bool
	KeyChannel   chan KeyAll
	MouseChannel chan any
	main
	monitor
	debug
	KeyboardData   datastruct.KeyboardData
	CurrentPressed CurrentPressed
}

type CurrentPressed struct {
	sync.Map
}

type main struct {
	addr *net.UDPAddr
	mac  string
	conn *net.UDPConn
	send chan datastruct.ClientTx
	recv chan datastruct.ClientTx
	tx   datastruct.ClientTx
}

type monitor struct {
	MonitorPort    uint32
	connMonitor    *net.UDPConn
	mouseReport    chan datastruct.StandardMouseReport
	keyboardReport chan datastruct.StandardKeyboardReport
	KeyState       keyboardState
}

type debug struct {
	DebugPort   uint32
	connDebug   *net.UDPConn
	debugReport chan []byte
}

func (self *Km) Ready() {
	self.debugReport = make(chan []byte, 10)
	self.mouseReport = make(chan datastruct.StandardMouseReport, 10)
	self.keyboardReport = make(chan datastruct.StandardKeyboardReport, 10)
	self.KeyChannel = make(chan KeyAll, 10)
	self.MouseChannel = make(chan any, 10)
	self.send = make(chan datastruct.ClientTx, 10)
	self.recv = make(chan datastruct.ClientTx, 10)
	Indexpts.Store(uint32(time.Now().Unix()))
	for i := 0; i < runtime.NumCPU(); i++ {
		go self.sender()
	}
}

func (self *Km) server_monitor() {

	go self.MonitorMouse()
	go self.MonitorKeyboard()

	for {
		buffer := make([]byte, 1024)
		lens, err := self.connMonitor.Read(buffer)
		if err != nil {
			fmt.Sprintln("Monitor接收错误:", err)
			return
		}

		mouseReport := datastruct.StandardMouseReport{}
		mouseBuff := bytes.NewReader(buffer[:unsafe.Sizeof(mouseReport)]) // 前7个字节是鼠标报告
		if err := binary.Read(mouseBuff, binary.NativeEndian, &mouseReport); err != nil {
			panic(fmt.Sprintln("Monitor-鼠标数据整合错误:", err))
		}

		// 解析标准键盘报告
		keyboardReport := datastruct.StandardKeyboardReport{}
		keyboardBuff := bytes.NewReader(buffer[unsafe.Sizeof(mouseReport) : unsafe.Sizeof(mouseReport)+unsafe.Sizeof(keyboardReport)]) // 剩下的字节是键盘报告
		if err := binary.Read(keyboardBuff, binary.NativeEndian, &keyboardReport); err != nil {
			panic(fmt.Sprintln("Monitor-键盘数据整合错误:", err, unsafe.Sizeof(keyboardReport)))
		}
		self.mouseReport <- mouseReport
		self.keyboardReport <- keyboardReport
		if self.DebugClient {
			fmt.Println("Monitor收到数据长度:", lens)
		}

	}
}

func (self *Km) server_debug() {
	//defer self.connDebug.Close()
	for {
		buffer := make([]byte, 1024)
		if _, err := self.connDebug.Read(buffer); err != nil {
			panic(fmt.Sprintln("Monitor接收错误:", err))
		}
		self.debugReport <- buffer
		if self.DebugClient {
			fmt.Println("Debug数据包长度:", len(buffer), "内容:", buffer)
		}
	}
}

var Indexpts = atomic.Uint32{}

func (self *Km) sender() {
	for tx := range self.send {
		Indexpts.Add(1)
		tx.Head.Indexpts = Indexpts.Load()
		var buf bytes.Buffer
		err := binary.Write(&buf, binary.NativeEndian, &tx.Head)
		if err != nil {
			panic(fmt.Sprintln("binary编译失败", err))
		}
		switch tx.Head.Cmd {
		case cmd.CmdKeyboardAll:
			err := binary.Write(&buf, binary.NativeEndian, &tx.CmdKeyboard)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break
		case cmd.CmdShowPic, cmd.CmdSetConfig:
			err := binary.Write(&buf, binary.NativeEndian, &tx.U8Buff)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break

		case cmd.CmdMouseWheel, cmd.CmdMouseLeft, cmd.CmdMouseRight, cmd.CmdMouseMiddle, cmd.CmdMouseAutoMove, cmd.CmdMouseMove:
			err := binary.Write(&buf, binary.NativeEndian, &tx.CmdMouse)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break
		}

		buffer := buf.Bytes()
		if _, err := self.conn.Write(buffer); err != nil {
			panic(fmt.Sprintln("发送错误:", err))
		}
		if self.DebugClient {
			fmt.Println(Indexpts.Load(), "已发送数据包长度:", len(buffer))
		}
	}
	panic(fmt.Sprintln("发送通道关闭"))
}

func (self *Km) receiver() {
	for {
		rx := datastruct.ClientTx{}
		buffer := make([]byte, 2048)
		if _, err := self.conn.Read(buffer); err != nil {
			fmt.Sprintln("接收错误:", err)
			return
			//panic(fmt.Sprintln("接收错误:", err))
		}
		buf := bytes.NewReader(buffer)
		err := binary.Read(buf, binary.NativeEndian, &rx.Head)
		if err != nil {
			panic(fmt.Sprintln("binary编译失败", err))
		}
		switch rx.Head.Cmd {
		case cmd.CmdKeyboardAll:
			err := binary.Read(buf, binary.NativeEndian, &rx.CmdKeyboard)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break
		case cmd.CmdShowPic, cmd.CmdSetConfig:
			err := binary.Read(buf, binary.NativeEndian, &rx.U8Buff)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break
		case cmd.CmdMouseWheel, cmd.CmdMouseLeft, cmd.CmdMouseRight, cmd.CmdMouseMiddle, cmd.CmdMouseAutoMove, cmd.CmdMouseMove:
			err := binary.Read(buf, binary.NativeEndian, &rx.CmdMouse)
			if err != nil {
				panic(fmt.Sprintln("binary编译失败", err))
			}
			break
		}
		self.recv <- rx
		if self.DebugClient {
			fmt.Println("接收数据包长度:", buf.Len())
		}
	}
	panic(fmt.Sprintln("接收通道关闭"))
}
