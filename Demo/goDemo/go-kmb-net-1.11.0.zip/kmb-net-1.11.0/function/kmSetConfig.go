package function

import (
	"encoding/binary"
	"fmt"
	"main.go/define/cmd"
	"net"
)

func (self *Km) KmNetSetConfig(IP string, port uint16) (err error) {
	self.tx.Head.Cmd = cmd.CmdSetConfig
	ip := net.ParseIP(IP)
	ip4 := ip.To4()
	if ip4 == nil {
		panic(fmt.Sprintln("ipv4 err:", err))
	}
	self.tx.U8Buff.Buff[0] = byte(port >> 8)
	self.tx.U8Buff.Buff[1] = byte(port >> 0)

	self.tx.Head.Rand = binary.BigEndian.Uint32(ip4)
	self.send <- self.tx
	return
}
