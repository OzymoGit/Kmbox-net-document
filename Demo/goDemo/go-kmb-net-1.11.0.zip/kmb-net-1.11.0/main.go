package main

import (
	"main.go/action"
	"main.go/function"
)

func main() {
	var km function.Km
	//km.KeyState.KeyBoardDebug = true
	//km.KeyState.MouseDebug = true
	//km.DebugClient = false
	km.MonitorPort = 10000

	km.Ready()
	_ = km.KmNetInit("192.168.2.188", 8384, "24c35054")
	km.MainRouter()
	//_ = km.KmNetDebug()
	//km.KmNetSetVidPid(0x05ac, 0x0256)
	//km.KmNetMaskKeyboard(hid.CmdE)
	var run action.Runnable
	run.MainRun(&km)
}
