package action

import "fmt"

type mouse struct {
}

func (self *Runnable) mouse_runnable() {
	for c := range self.km.MouseChannel {
		fmt.Println("匹配鼠標", c)
	}
	panic("鼠标通道意外结束")
}
