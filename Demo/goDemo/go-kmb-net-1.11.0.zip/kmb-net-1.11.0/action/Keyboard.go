package action

import (
	hid "main.go/define/hid"
	"main.go/function"
)

type keyboard struct {
	模式1 bool
	key
}

func (self *Runnable) keyboard_runnable() {
	self.km.KmNetMaskKeyboard(hid.CmdPrintScreen)
	self.km.KmNetMaskKeyboard(hid.CmdPause)
	self.km.KmNetMaskKeyboard(hid.CmdScrollLock)
	self.km.KmNetMaskKeyboard(hid.CmdRightControl)
	for c := range self.km.KeyChannel {
		go self.kb_actvate(c.KeyPressed, c.KeyStayPressed)
		go self.kb_setpid(c.KeyPressed, c.KeyStayPressed)
		go self.test_key(c.KeyPressed, c.KeyStayPressed)
		go self.qe_main(c.KeyPressed, c.KeyStayPressed)
		go self.whel_main(c.KeyPressed, c.KeyStayPressed)
	}
	panic("键盘通道意外结束")
}

func (self *Runnable) kb_actvate(c, d *function.KeyPressed) {
	if c.RightCtrl && c.ScrollLock {
		go self.km.KmNetLcdPicture("GoLang")
		//fmt.Println("快捷键激活功能")
	} else {
		go self.key_main(c, d)
		//fmt.Println("按下按键", c.RightCtrl, c.ScrollLock)
	}

}

func (self *Runnable) kb_setpid(c, d *function.KeyPressed) {
	if c.RightCtrl && c.RightAlt && c.PauseBreak {
		//self.km.KmNetSetVidPid(0x05ac, 0x0256)
		self.km.KmNetReboot()
	}
}

func (self *Runnable) test_key(c, d *function.KeyPressed) {
	if c.RightCtrl && c.PauseBreak {
		//self.km.KmNetReboot()
		//self.km.KmNetMouseWheel(1)
		//time.Sleep(100 * time.Millisecond)
		//self.km.KmNetMouseWheel(-1)
		//self.km.KmNetMouseWheel(1)
	}
}
