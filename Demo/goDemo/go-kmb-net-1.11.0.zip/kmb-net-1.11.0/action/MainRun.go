package action

import (
	"main.go/function"
)

type Runnable struct {
	//将你需要缓存的数据存在这里
	km *function.Km
	keyboard
	mouse
}

func (self *Runnable) MainRun(km *function.Km) {
	self.km = km
	go self.mouse_runnable()
	self.keyboard_runnable()
	panic("runnable")
}
