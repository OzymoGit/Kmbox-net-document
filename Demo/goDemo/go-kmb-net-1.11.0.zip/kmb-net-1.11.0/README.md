# KmNet Golang Version

# Linux Installing

touch /etc/systemd/system/km.service

```shell
echo "[Service]
Type=simple
Restart=never
#Restart=always
#RestartSec=5s
ExecStart=/root/km_linux
WorkingDirectory=/root/
[Install]
WantedBy=multi-user.target">/etc/systemd/system/km.service
```

# Update Log

- v1.0.0
    - 初版，仅完成init方法
- v1.1.0
    - 新增monitor
    - 新增Debug（固件还未支持）
    - 新增Monitorport/DebugPort：手动/自动设置
    - 新增本地回报开关，默认静默模式
- v1.2.0
    - 新增Monitor接收模式
    - 新增系统参数修改（IP地址端口修改）
- v1.3.0
    - 新增鼠标异步处理接收模式
    - 新增键盘功能键位映射模式
    - 新增键盘异步并发多线程处理模式
- v1.4.0
    - 新增数据Channel回传模式代码解耦
    - 新增各类Monitor回传消息解析
- v1.5.0
    - 修复键盘参数模式，并优化虚拟线程的数据安全
    - 新增PIDVID修改
- v1.6.0
    - 新增文字生成接口，通过km.KmNetLcdPicture(分辨率问题，目前只能显示10位String)
- v1.7.0
    - 新增键盘原数据输入(OriginalPressed)，方便实时进行Mask或UnMask
    - 新增KeyDown，KeyUp来实时开启按键屏蔽功能
    - 修复因为线程安全导致已经按下的按键被意外弹起的BUG
    - 新增键盘Demo
- v1.8.0
    - 修复PIDVID修改不生效的BUG（需要更新固件）
    - 新增自动重启重连功能，在重启设备后会触发自动重连（仅用于重启重连）
    - 新增快捷键Demo
- v1.9.0
    - 新增Keydown，KeyUp控制模块，使用线程安全的多线程调度器
    - 优化发送模式，减少发包量提高性能
    - 新增鼠标滚轮操作
    - 新增鼠标移动
    - 新增鼠标左键
    - 新增鼠标右键
    - 新增修正Mask，Unmask，UnmaskAll方法可能失效的问题
- v1.10.0
    - 修正小屏幕DPI显示效果,容纳更多字符
    - 修正多线程调用屏幕显示功能时可能因变量脏读导致Panic的故障
    - 新增香橙派(OrangePi)开发板自启动shell-service，理论上可用于所有类型ARM开发板
    - 优化数模结构，减少发包量&判断量提高性能
    - 新增鼠标数模结构优化
    - 修复键盘鼠标数模发送后失效的BUG
- v1.10.1
    - 修复“按键保持”时出现的多重执行问题，目前的执行模式和B版相同
- v1.11.0
    - 新增按键保持通道，可以使用按键保持通道来避免出现“按不出的键位”
    - 新增多线程发包，线程数量依赖CPU核心数量，提高发送效率避免快速操作时数据包排序“后发先至”
    - 新增原子排序，避免PTS重复或其他故障