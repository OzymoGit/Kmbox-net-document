package datastruct

type StandardMouseReport struct {
	ReportID uint8
	Buttons  uint8
	X        int16
	Y        int16
	Wheel    int16
}
