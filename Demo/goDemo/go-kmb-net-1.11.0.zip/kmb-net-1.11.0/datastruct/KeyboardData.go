package datastruct

type KeyboardData struct {
	Ctrl   byte
	Resv   byte
	Button [10]byte
}
